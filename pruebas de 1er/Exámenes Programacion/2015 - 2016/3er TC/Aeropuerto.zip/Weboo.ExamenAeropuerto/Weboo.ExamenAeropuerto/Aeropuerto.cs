﻿using System;
using System.Collections.Generic;
using System.Linq;
using Weboo.ExamenAeropuerto.Interfaces;

namespace Weboo.ExamenAeropuerto
{
    public class Aeropuerto : IAeropuerto
    {
        public Aeropuerto(int pesoMax, int[] tablaPesos, int[] tablaCostos, int colasSinDeclaracion, int colasConDeclaracion)
        {

        }
        
        public void LlegaAvion(IEnumerable<IPasajero> pasajeros)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IPasajero> SalidaDePasajeros()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IPasajero> EnColaSinDeclaracion(int cola)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IPasajero> EnColaConDeclaracion(int cola)
        {
            throw new NotImplementedException();
        }

        public int TiempoMaximoDeEspera
        {
            get { throw new NotImplementedException(); }
        }

        public int RecargoTotalPagado
        {
            get { throw new NotImplementedException(); }
        }
    }
}
