﻿using System;
using System.Collections.Generic;
using System.Linq;
using Weboo.ExamenAeropuerto;
using Weboo.ExamenAeropuerto.Interfaces;

namespace Tester
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tablaPesos = { 30, 50, 70 };
            int[] tablaCostos = { 10, 15, 20 };
            
            Aeropuerto aeropuerto = new Aeropuerto(30, tablaPesos, tablaCostos, 1, 2); 

            aeropuerto.LlegaAvion(new IPasajero[]
            {
                new Pasajero("Juan", new Bulto("Mochila", 15), new Bulto("Cámara", 5)), 
                new Pasajero("Pedro", new Bulto("Electrodomésticos", 40)),
                new Pasajero("Enrique", new Bulto("Alimentos", 5), new Bulto("Ropa", 10)), 
                new Pasajero("José", new Bulto("Alimentos", 10), new Bulto("Ropa", 20)),
                new Pasajero("Miguel", new Bulto("Ropa", 20), new Bulto("Electrónica", 35)),
            });

            // Cola sin declaración
            foreach (var pasajero in aeropuerto.EnColaSinDeclaracion(0))
                Console.WriteLine("{0}: {1} bulto(s)", pasajero.Nombre, pasajero.Equipaje.Count);

            // Juan: 2 bulto(s)
            // Enrique: 2 bulto(s)
            // José: 2 bulto(s)

            // Cola con declaración 1
            foreach (var pasajero in aeropuerto.EnColaConDeclaracion(0))
                Console.WriteLine("{0}: {1} bulto(s)", pasajero.Nombre, pasajero.Equipaje.Count);

            // Pedro: 1 bulto(s)

            // Cola con declaración 2
            foreach (var pasajero in aeropuerto.EnColaConDeclaracion(1))
                Console.WriteLine("{0}: {1} bulto(s)", pasajero.Nombre, pasajero.Equipaje.Count);

            // Miguel: 2 bulto(s)

            // Primer paso
            foreach (var pasajero in aeropuerto.SalidaDePasajeros())
                Console.WriteLine("{0}: ${1}", pasajero.Nombre, pasajero.CantidadAPagar);

            // Juan: $0
            // Pedro: $100

            // Segundo paso
            foreach (var pasajero in aeropuerto.SalidaDePasajeros())
                Console.WriteLine("{0}: ${1}", pasajero.Nombre, pasajero.CantidadAPagar);

            // Enrique: $0
            // Miguel: $275

            aeropuerto.LlegaAvion(new IPasajero[]
            {
                new Pasajero("Antonio", new Bulto("Alimentos", 15), new Bulto("PC", 20), new Bulto("Ropa", 25), new Bulto("Ropa", 25)), 
                new Pasajero("María", new Bulto("Bisutería", 10), new Bulto("Ropa", 40)),
                new Pasajero("Alien", new Bulto("Huevos", 40)), 
            });

            // Cola sin declaración
            foreach (var pasajero in aeropuerto.EnColaSinDeclaracion(0))
                Console.WriteLine("{0}: {1} bulto(s)", pasajero.Nombre, pasajero.Equipaje.Count);

            // José: 2 bulto(s)

            // Cola con declaración 1
            foreach (var pasajero in aeropuerto.EnColaConDeclaracion(0))
                Console.WriteLine("{0}: {1} bulto(s)", pasajero.Nombre, pasajero.Equipaje.Count);

            // Antonio: 4 bulto(s)
            // Alien: 1 bulto(s)

            // Cola con declaración 2
            foreach (var pasajero in aeropuerto.EnColaConDeclaracion(1))
                Console.WriteLine("{0}: {1} bulto(s)", pasajero.Nombre, pasajero.Equipaje.Count);

            // María: 2 bulto(s)

            // Tercer paso
            foreach (var pasajero in aeropuerto.SalidaDePasajeros())
                Console.WriteLine("{0}: ${1}", pasajero.Nombre, pasajero.CantidadAPagar);

            // José: $0

            // Cuarto paso
            foreach (var pasajero in aeropuerto.SalidaDePasajeros())
                Console.WriteLine("{0}: ${1}", pasajero.Nombre, pasajero.CantidadAPagar);

            // María: $200

            // Quinto paso
            foreach (var pasajero in aeropuerto.SalidaDePasajeros())
                Console.WriteLine("{0}: ${1}", pasajero.Nombre, pasajero.CantidadAPagar);

            // ...

            // Sexto paso
            foreach (var pasajero in aeropuerto.SalidaDePasajeros())
                Console.WriteLine("{0}: ${1}", pasajero.Nombre, pasajero.CantidadAPagar);

            // Antonio: $800

            // Séptimo paso
            foreach (var pasajero in aeropuerto.SalidaDePasajeros())
                Console.WriteLine("{0}: ${1}", pasajero.Nombre, pasajero.CantidadAPagar);

            // Alien: $100

            Console.WriteLine(aeropuerto.RecargoTotalPagado);   // 1475
            Console.WriteLine(aeropuerto.TiempoMaximoDeEspera); // 5
        }
    }

    class Bulto : IBulto
    {
        public Bulto(string descripcion, int peso)
        {
            Descripcion = descripcion;
            Peso = peso;
        }

        public string Descripcion { get; private set; }

        public int Peso { get; private set; }
    }

    class Pasajero : IPasajero
    {
        public Pasajero(string nombre, params IBulto[] equipaje)
        {
            Nombre = nombre;
            Equipaje = new List<IBulto>(equipaje);
        }

        public string Nombre { get; private set; }

        public IList<IBulto> Equipaje { get; private set; }

        public int CantidadAPagar { get; set; }
    }
}
