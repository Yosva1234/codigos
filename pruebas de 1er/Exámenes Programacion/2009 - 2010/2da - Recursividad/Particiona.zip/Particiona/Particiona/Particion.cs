using System;
using System.Collections.Generic;
using System.Text;

namespace Particiona
{
    public class Particion
    {
        public static int[] Partici�nBalanceada(int[] original, int n)
        {
            //TODO: Escriba su implementacion aqui.
            throw new NotImplementedException();
        }
    }
}
