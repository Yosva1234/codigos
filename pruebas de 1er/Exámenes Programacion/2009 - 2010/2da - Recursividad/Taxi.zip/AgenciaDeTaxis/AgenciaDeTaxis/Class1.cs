using System;
using System.Collections.Generic;
using System.Text;

namespace AgenciaDeTaxis
{
    public class Taxista
    {
        public static int CantidadDeCaminos(int X, int Y)
        {
            // Implemente su algoritmo aqui...
            return 0;
        }
    }
}
