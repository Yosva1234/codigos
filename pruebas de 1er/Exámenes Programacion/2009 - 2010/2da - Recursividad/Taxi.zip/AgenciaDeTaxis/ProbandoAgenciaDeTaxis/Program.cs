using System;
using System.Collections.Generic;
using System.Text;
using AgenciaDeTaxis;

namespace ProbandoAgenciaDeTaxis
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Taxista.CantidadDeCaminos(5, 3) + " debe ser 56");
        }
    }
}
