﻿using System;
using System.Collections.Generic;
using System.Text;
using Grouping;

namespace GroupingTest
{
    class Program
    {
        public static void Print<T, K>(IGroupEnumerator<T, K> e)
        {
            while (e.MoveNextGroup())
            {
                Console.WriteLine(e.CurrentKey);
                Console.WriteLine("-----------");
                while (e.MoveNext())
                    Console.WriteLine("  " + e.Current);
            }
        }

        static void Main(string[] args)
        {
            int[] numbers = new int[] { 2, 4, 5, 7, 9, 10, 14, 132 };
            Person[] persons = new Person[] { 
                new Person ("Juan", 20),
                new Person ("Ana", 19),
                new Person ("Alberto", 23),
                new Person ("Carlos", 20),
                new Person ("Chucho", 19),
                new Person ("Maria", 18)
            };

            #region Pares e impares

            Console.WriteLine("Agrupando pares e impares...-----------------------------");
            Print<int, bool>(Grouper.GroupBy<int, bool>(numbers, new ParitySelector()));
            Console.WriteLine();

            #endregion

            #region Numero de digitos

            Console.WriteLine("Agrupando por cantidad de digitos...-----------------------------");
            Print<int, int>(Grouper.GroupBy<int, int>(numbers, new NumerOfDigitsSelector()));
            Console.WriteLine();

            #endregion

            #region Primera letra

            Console.WriteLine("Agrupando por primera letra...-----------------------------");
            Print<Person, char>(Grouper.GroupBy<Person, char>(persons, new FirstLetterSelector()));
            Console.WriteLine();

            #endregion

            #region Por edad

            Console.WriteLine("Agrupando por edad...-----------------------------");
            Print<Person, int>(Grouper.GroupBy<Person, int>(persons, new AgeSelector()));
            Console.WriteLine();

            #endregion

            Console.ReadLine();
        }
    }

    public class Person
    {
        private string _Name;

        public string Name { get { return _Name; } }

        private int _Age;

        public int Age { get { return _Age; } }

        public Person(string name, int age)
        {
            this._Name = name;
            this._Age = age;
        }

        public override string ToString()
        {
            return Name + " (" + Age + ")";
        }
    }

    #region Selectors

    public class ParitySelector : ISelector<int, bool>
    {
        public bool Select(int obj)
        {
            return obj % 2 == 0;
        }
    }

    public class NumerOfDigitsSelector : ISelector<int, int>
    {
        public int Select(int obj)
        {
            return obj.ToString().Length;
        }
    }

    public class FirstLetterSelector : ISelector<Person, char>
    {
        public char Select(Person obj)
        {
            return obj.Name[0];
        }
    }

    public class AgeSelector : ISelector<Person, int>
    {
        public int Select(Person obj)
        {
            return obj.Age;
        }
    }

    #endregion
}
