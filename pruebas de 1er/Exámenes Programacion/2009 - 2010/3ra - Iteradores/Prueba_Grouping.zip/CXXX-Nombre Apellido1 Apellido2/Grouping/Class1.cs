﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Grouping
{
    public class Grouper
    {
        public static IGroupEnumerator<T, K> GroupBy<T, K>(IEnumerable<T> elements, ISelector<T, K> selector)
        {
            // Remplace esta linea por su codigo.
            throw new NotImplementedException();
        }
    }

    
}
