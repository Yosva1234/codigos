﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Domino;

namespace Weboo.Examen
{
    public class JuegoDeDomino : IJuegoDeDomino
    {
        public JuegoDeDomino() // Su tipo no puede tener otros constructores especializados
        {
            // Implemente aquí cualquier inicialización de su tipo.
        }

        /// <summary>
        /// Debe iniciar un nuevo juego con una determinada cantidad de jugadores.
        /// </summary>
        public void IniciaJuego(int cantidadDeJugadores)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Debe devolver la cantidad de jugadores con que se inició el juego.
        /// </summary>
        public int CantidadDeJugadores
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Luego de iniciado un juego se reparte a cada jugado sus fichas y se determina qué estrategia utilizará.
        /// El primer llamado configura el jugador 0, el segundo llamado el jugador 1, etc.
        /// </summary>
        public void CreaJugador(IEstrategia estrategia, IEnumerable<Ficha> fichasIniciales)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// En cualquier momento del juego se puede consultar las fichas de algun jugador a través de este método.
        /// </summary>
        public IEnumerable<Ficha> FichasDe(int jugador)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Ejecuta un turno consistente en:
        /// si el jugador actual tiene una ficha posible para jugar se consulta su estrategia y se realizan los cambios pertinentes (se realiza la jugada).
        /// Se pasa el turno al próximo jugador
        /// </summary>
        public void Juega()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Devuelve un enumerable con los indices de los jugadores ganadores.
        /// Si el juego no ha terminado debe devolver un enumerable vacío.
        /// Si algún jugador se pegó se debe devolver un enumerable con un único elemento igual al índice del jugador pegao'
        /// Si se trancó, todos aquellos jugadores que hayan alcanzado la mínima puntuación.
        /// </summary>
        public IEnumerable<int> Ganadores
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Devuelve true si el juego se terminó, ya sea porque se pegó un jugador o porque se pasaron N jugadores consecutivamente.
        /// </summary>
        public bool JuegoTerminado
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Devuelve el índice del jugador actual al que le toca jugar
        /// </summary>
        public int JugadorActual
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Devuelve un enumerable con el estado del tablero
        /// </summary>
        public IEnumerable<Ficha> Tablero
        {
            get { throw new NotImplementedException(); }
        }
    }
}
