﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Domino;
using Weboo.Examen;

namespace Probador
{
    class Program
    {
        static void Main(string[] args)
        {
            IJuegoDeDomino juego = new JuegoDeDomino();

            var estrategia = new LaPrimeraQueMeEncuentre();

            juego.IniciaJuego(4);

            juego.CreaJugador(estrategia, new Ficha[] { new Ficha(2, 4), new Ficha(1, 2), new Ficha(1, 4) });
            juego.CreaJugador(estrategia, new Ficha[] { new Ficha(2, 3), new Ficha(2, 2), new Ficha(0, 1) });
            juego.CreaJugador(estrategia, new Ficha[] { new Ficha(1, 3), new Ficha(1, 1), new Ficha(0, 4) });
            juego.CreaJugador(estrategia, new Ficha[] { new Ficha(0, 2), new Ficha(4, 4), new Ficha(3, 3) });

            while (!juego.JuegoTerminado)
            {
                for (int i = 0; i < juego.CantidadDeJugadores; i++)
                    Console.WriteLine("Jugador " + i + ": " + string.Join("", juego.FichasDe(i)) + (i == juego.JugadorActual ? "<" : ""));
                juego.Juega();
                Console.WriteLine("Tablero: " + string.Join("", juego.Tablero));
                Console.WriteLine();
            }

            Console.WriteLine("Juego terminado");
            Console.WriteLine("Ganador(es) " + string.Join(", ", juego.Ganadores));
            Console.ReadLine();
        }
    }

    class LaPrimeraQueMeEncuentre : IEstrategia
    {

        public Jugada DimeJugada(IEnumerable<Ficha> fichasDelJugador, IEnumerable<Ficha> tableroActual)
        {
            if (!tableroActual.Any())
                return new Jugada(fichasDelJugador.First(), Extremo.Izquierdo);

            int extremoIzquierdo = tableroActual.First().NumeroIzquierdo;
            int extremoDerecho = tableroActual.Last().NumeroDerecho;

            foreach (var f in fichasDelJugador)
            {
                if (f.NumeroDerecho == extremoIzquierdo)
                    return new Jugada(f, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoIzquierdo)
                    return new Jugada(f.Girada, Extremo.Izquierdo);
                if (f.NumeroIzquierdo == extremoDerecho)
                    return new Jugada(f, Extremo.Derecho);
                if (f.NumeroDerecho == extremoDerecho)
                    return new Jugada(f.Girada, Extremo.Derecho);
            }
            throw new InvalidOperationException("No existen fichas que se puedan jugar");
        }
    }

}
