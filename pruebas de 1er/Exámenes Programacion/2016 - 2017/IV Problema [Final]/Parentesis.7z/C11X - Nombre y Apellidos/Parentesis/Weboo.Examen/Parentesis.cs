﻿using System.Collections.Generic;

namespace Weboo.Examen
{
	public class Parentesis
	{
		public static IEnumerable<string> ParentesisBalanceadosConProfundidad(int n, int d)
		{
			yield break;
		}
	}
}