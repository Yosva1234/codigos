﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Weboo.Examen;

namespace TestApp
{
	static class Program
	{
		static void Main()
		{
			Tests();
			if (Debugger.IsAttached) Console.ReadKey();
		}

		static void Tests()
		{
			int n = 0;
			int d = 0;
			Console.WriteLine("1/4 - Cadenas de {0} paréntesis balanceados con profundidad {1}", 2 * n, d);

			string[] solucion = new string[] { "" };
			var respuesta = Parentesis.ParentesisBalanceadosConProfundidad(n, d);
			if (PrintDif(solucion, respuesta)) return;

			//############################################################################################
			n = 4;
			d = 2;
			Console.WriteLine("2/4 - Cadenas de {0} paréntesis balanceados con profundidad {1}", 2 * n, d);

			solucion = new string[] { "(()()())", "(()())()", "(())(())", "(())()()", "()(()())", "()(())()", "()()(())" };
			respuesta = Parentesis.ParentesisBalanceadosConProfundidad(n, d);
			if (PrintDif(solucion, respuesta)) return;

			//############################################################################################
			n = 15;
			d = 13;
			Console.WriteLine("3/4 - Cadenas de {0} paréntesis balanceados con profundidad {1}", 2 * n, d);

			solucion = new string[0];
			FileStream fs = null;
			try
			{
				fs = new FileStream("sols15_13.txt", FileMode.Open);
				solucion = new StreamReader(fs).ReadToEnd().Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
			}
			finally
			{
				if (fs != null) fs.Close();
			}
			respuesta = Parentesis.ParentesisBalanceadosConProfundidad(n, d);
			if (PrintDif(solucion, respuesta)) return;

			//############################################################################################
			n = 1000;
			d = 1000;
			Console.WriteLine("4/4 - Cadenas de {0} paréntesis balanceados con profundidad {1}", 2 * n, d);

			solucion = new string[] { new string('(', n) + new string(')', n) };
			respuesta = Parentesis.ParentesisBalanceadosConProfundidad(n, d);
			PrintDif(solucion, respuesta);
		}

		#region
		static bool PrintDif(string[] solucion, IEnumerable<string> respuesta, int max = 1000)
		{
			bool mal = false;
			const string e = "\"\"";

			var resp = new Dictionary<string, int>();
			int j = 0;
			foreach (var p in respuesta)
			{
				if (resp.ContainsKey(p))
				{
					"cadena repetida: {0}".colorprint(ConsoleColor.Yellow, p == string.Empty ? e : p);
					mal = true;
					continue;
				}

				resp[p] = j++;

				if (j < max) continue;
				"Mostrando solamente los primeros {0} resultados".colorprint(ConsoleColor.Red, max);
				mal = true;
				break;
			}

			for (int i = 0, k = 0; i < solucion.Length; i++)
			{
				int index;
				var s = solucion[i] == string.Empty ? e : solucion[i];
				if (!resp.TryGetValue(solucion[i], out index))
				{
					"falta: {0}".colorprint(ConsoleColor.Red, s);
					mal = true;
					continue;
				}
				if (k == index) s.colorprint(ConsoleColor.Green);
				else
				{
					"fuera de orden: {0}".colorprint(ConsoleColor.Yellow, s);
					mal = true;
				}
				resp.Remove(solucion[i]);
				k++;
			}

			Console.WriteLine();
			if (resp.Count == 0) return mal;

			"Cadenas adicionales:".colorprint(ConsoleColor.Red);
			foreach (var resto in resp)
				(resto.Key == string.Empty ? e : resto.Key).colorprint(ConsoleColor.Red);

			Console.WriteLine();
			return true;
		}

		static void colorprint(this string text, ConsoleColor color, params object[] cargs)
		{
			var c = Console.ForegroundColor;
			Console.ForegroundColor = color;
			Console.WriteLine(text, cargs);
			Console.ForegroundColor = c;
		}
		#endregion
	}
}