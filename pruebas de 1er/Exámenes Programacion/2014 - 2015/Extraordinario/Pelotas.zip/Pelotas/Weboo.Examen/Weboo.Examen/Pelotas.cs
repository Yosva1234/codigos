﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Pelotas
    {
        public static int EnlazaOptimo(int[] pelotas)
        {
            /// elimine esta línea e implemente la función
            throw new NotImplementedException();
        }
    }
}
