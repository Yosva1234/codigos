﻿using System;
using Weboo.ExamenMundial.Interfaces;

namespace Weboo.ExamenMundial
{
    public static class SimplificandoArboles
    {
        public static int MinimaCantidadDeSimplificaciones<T>(IArbol<T> a, IArbol<T> b)
        {
            throw new NotImplementedException();
        }
    }
}
