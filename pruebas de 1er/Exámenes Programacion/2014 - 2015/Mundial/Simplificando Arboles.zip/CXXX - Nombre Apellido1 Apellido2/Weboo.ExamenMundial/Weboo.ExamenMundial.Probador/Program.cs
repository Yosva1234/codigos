﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.ExamenMundial.Interfaces;

namespace Weboo.ExamenMundial.Probador
{
    class Program
    {
        private static void Main(string[] args)
        {
            var a1 = new Arbol<string>("A",
                new Arbol<string>("X",
                    new Arbol<string>("C",
                        null,
                        new Arbol<string>("E")),
                    new Arbol<string>("D",
                        new Arbol<string>("F"),
                        new Arbol<string>("G"))),
                new Arbol<string>("B"));

            var a2 = new Arbol<string>("A",
                new Arbol<string>("X",
                    new Arbol<string>("C",
                        null,
                        new Arbol<string>("E")),
                    new Arbol<string>("F")),
                new Arbol<string>("B"));

            var a3 = new Arbol<string>("A",
                new Arbol<string>("X",
                    null,
                    new Arbol<string>("F")),
                new Arbol<string>("B"));

            var a4 = new Arbol<string>("X",
                null,
                new Arbol<string>("F"));

            var a5 = new Arbol<string>("A",
                new Arbol<string>("X",
                    new Arbol<string>("Y"),
                    new Arbol<string>("Z")),
                new Arbol<string>("B"));

            Console.WriteLine(SimplificandoArboles.MinimaCantidadDeSimplificaciones(a1, a2)); //  1
            Console.WriteLine(SimplificandoArboles.MinimaCantidadDeSimplificaciones(a1, a3)); //  2
            Console.WriteLine(SimplificandoArboles.MinimaCantidadDeSimplificaciones(a1, a4)); //  3
            Console.WriteLine(SimplificandoArboles.MinimaCantidadDeSimplificaciones(a1, a5)); // -1
        }
    }
}
