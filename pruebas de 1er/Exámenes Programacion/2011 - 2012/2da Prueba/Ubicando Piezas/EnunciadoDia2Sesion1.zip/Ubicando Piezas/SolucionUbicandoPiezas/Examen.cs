﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolucionUbicandoPiezas
{
    public class Examen
    {
        public static bool PuedenUbicarse(bool[][,] piezas, int alto, int ancho)
        {
            //TODO: Elimine la línea a continuación y escriba su solución
            throw new NotImplementedException();

        }
    }
}
