﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TCP2
{
    public class GuaguaConDesperfectos
    {
        public static int MayorCantidadDePersonas(int[,] personasPorCuadra, bool[,] talleres)
        {
            throw new NotImplementedException();
        }
    }
}
