﻿using System;
using System.Collections.Generic;

namespace Weboo.Examen
{
    public class MatrizEsparcida:IEnumerable<Celda>
    {
        List<Celda> _data = new List<Celda>();
        int _filas;
        int _columnas;
        /// <summary>
        /// Crea una instancia de MatrizEsparcida a partir de sus dimensiones.
        /// Inicialmente todos los elementos son cero;
        /// </summary>
        /// <param name="filas">Cantidad de filas de la nueva matriz.</param>
        /// <param name="columnas">Cantidad de columnas de la nueva matriz.</param>
        public MatrizEsparcida(int filas, int columnas)
        {
            if (filas <= 0 || columnas <= 0) throw new ArgumentException();
            
            _filas = filas;
            _columnas = columnas;
        }

        /// <summary>
        /// Retorna la cantidad de filas de la matriz.
        /// </summary>
        public int Filas { get { return _filas; } }

        /// <summary>
        /// Retorna la cantidad de columnas de la matriz;
        /// </summary>
        public int Columnas { get { return _columnas; } }

        /// <summary>
        /// Asigna o retorna el valor de un elemento de la matriz a partir de su posición.
        /// </summary>
        /// <param name="fila">La fila del elemento.</param>
        /// <param name="columna">La columna del elemento.</param>
        /// <returns>Retorna el valor de la celda o lanza IndexOutOfRangeException si la posición no es correcta.</returns>
        public int this[int fila, int columna] 
        { 
           
            get 
            {
                if (fila < 0 || fila >= _filas || columna < 0 || columna >= _columnas) throw new IndexOutOfRangeException();
                foreach (var item in _data)
                {
                    if (item.Columna==columna&&item.Fila==fila)
                    {
                        return item.Valor;
                    }
                }
                return 0;
            }

            set 
            {
                if (fila < 0 || fila >= _filas || columna < 0 || columna >= _columnas) throw new IndexOutOfRangeException();
                if (value != 0)
                {
                    bool b = false;
                    int place = 0;
                    foreach (var item in _data)
                    {
                        
                        if (item.Columna == columna && item.Fila==fila)
                        {
                            b = true;
                           
                            break;
                        }
                        place++;
                    }
                    if (!b) { _data.Add(new Celda(fila, columna, value)); Sort(); }
                    else _data[place] = new Celda(fila, columna, value);
                }
                else
                {
                    int place = 0;
                    bool encontrado = false;
                    foreach (var item in _data)
                    {
                        
                        if (item.Columna==columna&&item.Fila==fila)
                        {
                            encontrado = true;
                            break;
                        }
                        place++;
                    }
                    if(encontrado)
                    _data.RemoveAt(place);
                }
                
            }

        }

        /// <summary>
        /// Retorna la cantidad de celdas distintas de cero contenidas en la matriz.
        /// </summary>
        public int CeldasNoCero { get

        {
            return _data.Count;
        
        } }

        /// <summary>
        /// Retorna la matriz transpuesta.
        /// </summary>
        public MatrizEsparcida Transpuesta 
        {
            get
            {
                MatrizEsparcida r = new MatrizEsparcida(this._filas, this._columnas);

                for (int i = 0; i < this.CeldasNoCero; i++)
                {
                    r._data.Add(new Celda(_data[i].Columna, _data[i].Fila, _data[i].Valor));
                }
                r.Sort();
                r._filas = _columnas;
                r._columnas = _filas;
                return r;
            }
        }

        /// <summary>
        /// Calcula la suma de con otra matriz.
        /// </summary>
        /// <param name="m">Otra matriz esparcida.</param>
        /// <returns>Retorna una matriz que representa la suma..</returns>
        public MatrizEsparcida Suma(MatrizEsparcida m) 
        {
            if (m.Filas != this.Filas || m.Columnas != this.Columnas) throw new ArgumentException();

            MatrizEsparcida r = new MatrizEsparcida(m._filas, m._columnas);
            List<Celda> sumadas_this = new List<Celda>();
            for (int i = 0; i < m.CeldasNoCero; i++)
            {
                bool encntrado = false;
                for (int k = 0; k < this.CeldasNoCero; k++)
                {
                    if (m._data[i].Columna==_data[k].Columna&&m._data[i].Fila==_data[k].Fila)
                    {
                        encntrado = true;
                        r._data.Add(new Celda(m._data[i].Fila, m._data[i].Columna, m._data[i].Valor + _data[k].Valor));
                        break;
                    }
                   
                }
                if (!encntrado) 
                    {
                        r._data.Add(new Celda(m._data[i].Fila, m._data[i].Columna, m._data[i].Valor));
                    }
            }





            for (int i = 0; i < CeldasNoCero; i++)
            {
                bool encotrado = false;
                for (int k = 0; k < m.CeldasNoCero; k++)
                {
                    if (_data[i].Fila == m._data[k].Fila && _data[i].Columna == m._data[k].Columna) 
                    {
                        encotrado = true;
                        break;
                    }
                }
                if (!encotrado)
                {
                    r._data.Add(new Celda(_data[i].Fila, _data[i].Columna, _data[i].Valor));
                }
            }
            r.Sort();
            return r;
        }

        /// <summary>
        /// Retorna los elementos distintos de cero contenidos en una columna de la matriz ordenados por fila.
        /// </summary>
        /// <param name="columna">Columna de los elementos a retornar.</param>
        /// <returns>Un IEnumerable que contiene los elementos de la columna dada como parámetro ordenados por fila.</returns>
        public IEnumerable<Celda> ElementosEnColumna(int columna)
        {
            Sort();
            for (int i = 0; i < CeldasNoCero; i++)
            {
                if (_data[i].Columna == columna) yield return _data[i];
            }
        }

        /// <summary>
        /// Retorna los elementos distintos de cero contenidos en una fila de la matriz ordenados por columna.
        /// </summary>
        /// <param name="fila">Fila de los elementos a retornar.</param>
        /// <returns>Un IEnumerable que contiene los elementos de la fila dada como parámetro ordenados por columna.</returns>
        public IEnumerable<Celda> ElementosEnFila(int fila)
        {
            Sort();
            for (int i = 0; i < CeldasNoCero; i++)
            {
                if (_data[i].Fila == fila&&_data[i].Valor!=0) yield return _data[i];
            }
        }

        #region IEnumerable<Celda> Members

        public IEnumerator<Celda> GetEnumerator()
        {
            Sort();
            foreach (var item in _data)
            {
                if (item.Valor!=0)
                {
                    yield return item;
                }
            }
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        #endregion


        void Sort() 
        {
            _data.Sort((a,b)=>Comparador(a,b));
        }
        int Comparador(Celda a, Celda b) 
        {
            if (a.Fila > b.Fila) return 1;
            if (a.Fila < b.Fila) return -1;
            if (a.Fila == b.Fila) 
            {
                if (a.Columna > b.Columna) return 1;
                if (a.Columna < b.Columna) return -1;
            }
            return 0;
        }
    }
}
