﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class TelegrafoRoto
    {
        public static IEnumerable<string> DecodificarMensaje(Dictionary<char, string> alfabeto, string mensaje)
        {
            //Borre la siguiente línea y escriba su código
            throw new NotImplementedException();
        }
    }
}
