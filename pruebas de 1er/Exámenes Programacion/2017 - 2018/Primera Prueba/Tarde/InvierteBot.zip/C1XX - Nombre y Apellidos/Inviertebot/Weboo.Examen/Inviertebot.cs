﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen
{
    public class Inviertebot
    {
        public static int[] EjecutaInstrucciones(int n, int[] i, int[] d)
        {
            //Borre la siguiente línea y escriba su código
            throw new NotImplementedException("Tiene que borrar esta línea: throw new NotImplementedException(...)");
        }
    }
}
