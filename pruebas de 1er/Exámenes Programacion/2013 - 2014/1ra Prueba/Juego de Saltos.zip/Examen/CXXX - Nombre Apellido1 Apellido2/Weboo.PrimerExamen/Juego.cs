﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Weboo.PrimerExamen
{
    public class Juego
    {
        public static int PosicionFinal(int[] array, int[] tiradas)
        {
            // Borre esta línea e implemente su código aquí
            throw new NotImplementedException();
        }
    }
}
