﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Weboo.Arboles;

namespace Weboo.Examen.Final
{
    public class Recorridos
    {
        public static IEnumerable<R> IteraPrimeroHojas<T, R>(Arbol<T> arbol, Func<T, R> op)
        {
            /// Elimine esta línea inmediatamente...
            throw new NotImplementedException();
        }
    }

}
