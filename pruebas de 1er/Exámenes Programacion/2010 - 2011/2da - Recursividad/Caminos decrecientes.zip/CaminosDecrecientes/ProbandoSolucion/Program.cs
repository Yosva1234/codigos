﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CaminosDecrecientes;

namespace ProbandoSolucion
{
    class Program
    {
        static void Main(string[] args)
        {
            // aqui puede probar su codigo
        }
    }
}
