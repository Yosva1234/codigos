﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaminosDecrecientes
{
    public class Prueba
    {
        public static int CantidadCaminosDecrecientes(int[,] matriz, int fInic, int cInic,
                            int fFin, int cFin)
        {
            // ... Aquí va su implementación
            throw new NotImplementedException();
        }

    }
}
