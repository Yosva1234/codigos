﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DesencriptarCadena
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Decodifica("CAMINO", 23, "KAKAKSKSSS"));
            Console.WriteLine(Decodifica("CAMO", 21, "ASDASDASDASDASD"));
            Console.WriteLine(Decodifica("ASDFGH", 26, "FQFFFFFFFFDUQ"));
            Console.WriteLine(Decodifica("FEAO", 0, "FZXCZCXXXXXXUQ"));
            Console.WriteLine(Decodifica("CLZAO", 22, "FAAAAAAAAADDDD"));
            Console.WriteLine(Decodifica("GLIOP", 1, "BXCVBXVBCVB"));
            Console.WriteLine(Decodifica("KLEP", 7, "TYRYERYRYRYT"));
        }


        public static string Decodifica(string llave, int posicion, string texto)
        {
            if (posicion < 0 || posicion > 26)
                throw new ArgumentException("La posicion debe estar entre 0 y 26.");
            for (int i = 0; i < llave.Length - 1; i++)
                for (int j = i + 1; j < llave.Length; j++)
                    if (llave[i] == llave[j]) throw new ArgumentException("Llave incorrecta");
                

            string abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string result = "";
            string codigo = Codificacion(llave, posicion, abc);

            for (int i = 0; i < texto.Length; i++)
                result += abc[codigo.IndexOf(texto[i])];

            return result;
        }

        static string Codificacion(string llave, int pos, string abc)
        {
            char[] code = new char[26];

            int pos2 = 0;
            while (pos2 < llave.Length)
                code[pos++ - ((pos - 1) / code.Length * code.Length)] = llave[pos2++];

            pos2 = 0;
            int count = code.Length - llave.Length;
            while (count > 0)
            {
                if (!new string(code).Contains(abc[pos2++] + ""))
                {
                    code[pos++ - ((pos - 1) / code.Length * code.Length)] = abc[pos2 - 1];
                    count--;
                }
            }

            return new string(code);
        }




    }
}
