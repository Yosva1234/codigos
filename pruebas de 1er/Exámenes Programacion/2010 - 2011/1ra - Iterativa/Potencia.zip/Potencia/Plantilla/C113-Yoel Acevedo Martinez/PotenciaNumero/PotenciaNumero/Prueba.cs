using System;
using System.Collections.Generic;
using System.Text;

namespace PotenciaNumero
{
    public class Prueba
    {
        public static string ElevarAPotencia(string numero, int n)
        {
            if (string.IsNullOrEmpty(numero)) throw new ArgumentException("El par�metro pasado no puede ser null");
            if (n == 0) return "1";
            if (n == 1) return numero;

            BigDouble num = new BigDouble(numero);

            for (int i = 2; i <= n; i++)
                num = num * new BigDouble(numero);

            return num.Value;
        }
    }

    public class BigDouble
    {
        private string num;

        public BigDouble(string num)
        {
            this.num = num;
        }

        public string Value
        {
            get { return num; }
        }

        public static BigDouble operator +(BigDouble a, BigDouble b)
        {
            string result = "";
            int resto = 0;

            if (!a.num.Contains("."))
                a.num += ".0";
            string[] pieces_A = a.num.Split('.');

            if (!b.num.Contains("."))
                b.num += ".0";
            string[] pieces_B = b.num.Split('.');

            while (pieces_A[1].Length != pieces_B[1].Length)
            {
                if (pieces_A[1].Length < pieces_B[1].Length)
                    pieces_A[1] = pieces_A[1].Insert(0, "0");
                else pieces_B[1] = pieces_B[1].Insert(0, "0");
            }
            while (pieces_A[0].Length != pieces_B[0].Length)
            {
                if (pieces_A[0].Length < pieces_B[0].Length)
                    pieces_A[0] = pieces_A[0].Insert(0, "0");
                else pieces_B[0] = pieces_B[0].Insert(0, "0");
            }

            int temp;
            for (int i = pieces_B[1].Length - 1; i >= 0; i--)
            {
                temp = int.Parse(pieces_B[1][i] + "") + int.Parse(pieces_A[1][i] + "") + resto;

                if (temp >= 10)
                {
                    resto = 1;
                    temp -= 10;
                    result += temp;
                }
                else
                {
                    resto = 0;
                    result += temp;
                }
            }

            result += ".";

            for (int i = pieces_B[0].Length - 1; i > 0; i--)
            {
                temp = int.Parse(pieces_B[0][i] + "") + int.Parse(pieces_A[0][i] + "") + resto;

                if (temp >= 10)
                {
                    resto = 1;
                    temp -= 10;
                    result += temp;
                }
                else
                {
                    resto = 0;
                    result += temp;
                }
            }

            temp = int.Parse(pieces_B[0][0] + "") + int.Parse(pieces_A[0][0] + "") + resto;
            if (temp >= 10) result += ReverseInt(temp);
            else result += temp;

            return JustifyDouble(new BigDouble(Reverse(result)));

        }

        public static BigDouble operator *(BigDouble a, BigDouble b)
        {
            BigDouble result = new BigDouble("0");
            int decimalValues = 0;
            int resto = 0;
            
            string[] pieces_A;
            if (!a.num.Contains("."))
            {
                a.num += ".0";
                pieces_A = a.num.Split('.');
                a.num = a.num.Remove(a.num.IndexOf("."), 2);

            }
            else pieces_A = a.num.Split('.');

            string[] pieces_B;
            if (!b.num.Contains("."))
            {
                b.num += ".0";
                pieces_B = b.num.Split('.');
                b.num = b.num.Remove(b.num.IndexOf("."), 2);
            }
            else pieces_B = b.num.Split('.');


            decimalValues += pieces_A[1].Length + pieces_B[1].Length;
            if (a.num.Contains("."))
            a.num = a.num.Remove(a.num.IndexOf("."), 1);
            if (b.num.Contains("."))
            b.num = b.num.Remove(b.num.IndexOf("."), 1);

            for (int i = 0; i < b.num.Length; i++)
            {
                string temp = "";

                for (int j = a.num.Length - 1; j >= 0; j--)
                {
                    int mul = int.Parse(a.num[j] + "") * int.Parse(b.num[i] + "") + resto;

                    if (j != 0)
                    {
                        resto = mul / 10;
                        temp += mul - resto * 10;
                    }
                    else
                    {
                        resto = 0;
                        temp += ReverseInt(mul);
                    }
                }
                result.num += 0;
                result = result + new BigDouble(Reverse(temp));
            }

            if (decimalValues == 2)
                return JustifyDouble(result);

            if (decimalValues < result.num.Length)
                result.num = result.num.Insert(result.num.Length - decimalValues, ".");
            else
                result.num = result.num.Insert(0, "0.");

            return JustifyDouble(result);
        }

        public static BigDouble JustifyDouble(BigDouble a)
        {
            if (a.num.Contains("."))
            {
                for (int i = a.num.Length - 1; i > 1; i--)
                {
                    if ((a.num[i] == '0' && a.num[i - 1] == '0') || (a.num[i] == '0' && a.num[i - 1] != '0' && a.num[i - 1] != '.'))
                        a.num = a.num.Remove(i, 1);
                    else if (a.num[i] == '0' && a.num[i - 1] == '.')
                    {
                        a.num = a.num.Remove(i - 1, 2);
                        break;
                    }
                    else break;
                }
                return a;
            }

            return a;
        }

        static string Reverse(string result)
        {
            string reverseResult = "";
            for (int i = result.Length - 1; i >= 0; i--)
                reverseResult += result[i];

            return reverseResult;
        }
        static string ReverseInt(int a)
        {
            string temp = "";
            temp += a;

            return Reverse(temp);
        }
    }

}

