using System;
using System.Collections.Generic;
using System.Text;
using PotenciaNumero;

namespace ConsoleAppTesting
{
    class Program
    {
        static void Main(string[] args)
        {
            //BigDouble a = new BigDouble("95.123");
            //BigDouble b = new BigDouble("95.123");
            //BigDouble c = a * b;
            //Console.WriteLine(c.Value);

            string[] numeros = new string[] { "95.123", "0.4321", "5.1234", "6.7592", "98.999", "1.0100" };
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[0], 12));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[0], 12) == "548815620517731830194541.899025343415715973535967221869852721");
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[1], 20));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[1], 20) == "0.00000005148554641076956121994511276767154838481760200726351203835429763013462401");
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[2], 15));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[2], 15) == "43992025569.928573701266488041146654993318703707511666295476720493953024");
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[3], 9));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[3], 9) == "29448126.764121021618164430206909037173276672");
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[4], 10));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[4], 10) == "90429072743629540498.107596019456651774561044010001");
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[5], 12));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[5], 12) == "1.126825030131969720661201");

        }

    }
}
