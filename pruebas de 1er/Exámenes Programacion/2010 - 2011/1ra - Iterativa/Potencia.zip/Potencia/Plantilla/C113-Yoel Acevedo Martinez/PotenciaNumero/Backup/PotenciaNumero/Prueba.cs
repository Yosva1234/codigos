using System;
using System.Collections.Generic;
using System.Text;

namespace PotenciaNumero
{
    public class Prueba
    {
        public static string ElevarAPotencia(string numero, int n)
        {
            // ... Aqu� va su implementaci�n      
        }
    } 
}

