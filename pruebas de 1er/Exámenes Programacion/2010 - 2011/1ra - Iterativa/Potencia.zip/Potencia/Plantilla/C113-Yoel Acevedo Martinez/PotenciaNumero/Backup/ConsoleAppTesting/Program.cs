using System;
using System.Collections.Generic;
using System.Text;
using PotenciaNumero;

namespace ConsoleAppTesting
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] numeros = new string[] { "95.123", "0.4321", "5.1234", "6.7592", "98.999", "1.0100" };
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[0], 12));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[1], 20));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[2], 15));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[3], 9));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[4], 10));
            Console.WriteLine(Prueba.ElevarAPotencia(numeros[5], 12));
        }
    }
}
