using System.Collections.Generic;
using System;

namespace Weboo.TercerExamen.Solucion
{
    public class MiOrganizador : IOrganizador
    {
        #region IOrganizador Members

        public void AdicionaTarea(CPU cpu, Tarea tarea)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public CPU CreaCPU(long ciclosCPU)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Despierta(CPU cpu)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Duerme(CPU cpu)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public IEnumerable<Tarea> Ejecuta(long ciclos)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Tarea ProximaTarea()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public IEnumerable<Tarea> TareasEnCPU(CPU cpu)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public int TotalCPU
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        #endregion
    }
}
