using System;
using System.Collections.Generic;
using System.Text;
using Weboo.TercerExamen;
using Weboo.TercerExamen.Solucion;

namespace ProbandoSolucion
{
    class Program
    {
        static void Main(string[] args)
        {
            IOrganizador organizador = new MiOrganizador();

            CPU cpu1 = organizador.CreaCPU(75);
            organizador.AdicionaTarea(cpu1, new Tarea("X", 325));

            CPU cpu2 = organizador.CreaCPU(20);
            organizador.AdicionaTarea(cpu2, new Tarea("Y", 10));

            CPU cpu3 = organizador.CreaCPU(30);
            organizador.AdicionaTarea(cpu3, new Tarea("Z", 80));

            //Adicionando tareas del ejemplo
            organizador.AdicionaTarea(cpu1, new Tarea("C", 100));
            organizador.AdicionaTarea(cpu1, new Tarea("A", 175));
            organizador.AdicionaTarea(cpu2, new Tarea("M", 120));
            organizador.AdicionaTarea(cpu2, new Tarea("B", 60));
            organizador.AdicionaTarea(cpu3, new Tarea("R", 80));
            organizador.AdicionaTarea(cpu3, new Tarea("K", 110));

            Console.WriteLine("Respuesta Correcta es la Tarea: Y");
            Console.WriteLine(organizador.ProximaTarea());
            Console.WriteLine("Respuesta Correcta es la Tarea: Z");
            Console.WriteLine(organizador.ProximaTarea());
            Console.WriteLine("Respuesta Correcta es la Tarea: X");
            Console.WriteLine(organizador.ProximaTarea());

            foreach (Tarea tarea in organizador.Ejecuta(50))
            {
                //No debe ejecutarse esta instruccion,
                //pues no se finaliza ninguna tarea
                Console.WriteLine(tarea);
            }

            //En estos momentos el organizador debe tener la misma configuracion
            //que el ejemplo dado en la especificacion del problema
            Console.WriteLine("Respuesta Correcta es la Tarea: C");
            Console.WriteLine(organizador.ProximaTarea());

            Console.WriteLine("Respuesta Correcta son\n  Tarea: R\n  Tarea: M");
            foreach (Tarea tarea in organizador.Ejecuta(200))
                Console.WriteLine(tarea);

            //Continua Probando ...
            Console.WriteLine("Respuesta Correcta son\n  Tarea: A\n  Tarea: K\n  Tarea: B");
            foreach (Tarea tarea in organizador.Ejecuta(long.MaxValue))
                Console.WriteLine(tarea);
        }
    }
}
