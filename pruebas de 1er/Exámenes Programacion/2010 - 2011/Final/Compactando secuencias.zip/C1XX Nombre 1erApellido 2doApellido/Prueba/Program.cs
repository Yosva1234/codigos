﻿using System;
using System.Collections.Generic;
using System.Text;
using ExamenFinal;
using Weboo.Utils;

namespace Prueba
{
    class Program
    {
        static int Suma(int a, int b) { return a + b; }
        
        static T Min<T>(T a, T b) where T : IComparable
        {
            if (a.CompareTo(b) > 0)
                return b;
            return a;
        }
        
        static void Main(string[] args)
        {
            //Primer ejemplo
            //El resultado debe ser: 6 15 24 10
            int[] valores = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            foreach (int resultado in Iteradores.AgregaPorBloques(valores, Suma, 3))
            {
                Console.WriteLine(resultado);
            }

            //Segundo ejemplo
            //El resultado debe ser: "rojo" "amarillo" "blanco"
            string[] colores = { "rojo", "verde", "amarillo", "azul", "negro", "blanco" };
            foreach (string resultado in Iteradores.AgregaPorBloques(colores, Min, 2))
            {
                Console.WriteLine(resultado);
            }
        }
    }
}
