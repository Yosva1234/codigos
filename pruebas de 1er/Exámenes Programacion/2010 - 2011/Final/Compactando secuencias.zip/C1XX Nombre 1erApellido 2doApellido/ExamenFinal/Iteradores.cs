﻿using System;
using System.Collections.Generic;
using System.Text;
using Weboo.Utils;

namespace ExamenFinal
{
    public class Iteradores
    {
        public static IEnumerable<T> AgregaPorBloques<T>(IEnumerable<T> elementos, Operacion<T> operacion, int longitud)
        {
            //TODO: Escriba su código aquí
            return null;
        }
    }
}
