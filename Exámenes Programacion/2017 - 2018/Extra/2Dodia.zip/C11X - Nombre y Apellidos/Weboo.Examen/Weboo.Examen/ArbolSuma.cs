﻿using InterfacesArbolSuma;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Weboo.Examen
{
    public class ArbolSuma : IArbolSuma
    {
        public ArbolSuma(params int[] values)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IArbol<int>> PostOrden()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IArbol<int>> PreOrden()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IArbol<int>> Hojas()
        {
            throw new NotImplementedException();
        }

        public int Valor
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public IEnumerable<IArbol<int>> Hijos
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public void InsertarPreOrden(int k, IArbolSuma nuevo)
        {
            throw new NotImplementedException();
        }

        public void InsertarPostOrden(int k, IArbolSuma nuevo)
        {
            throw new NotImplementedException();
        }

        public void InsertarKHoja(int k, IArbolSuma nuevo)
        {
            throw new NotImplementedException();
        }

        public void Imprimir(string indent = "", bool last = false)
        {
            Console.Write(indent);
            Console.Write("| ");
            indent += "  ";

            Console.WriteLine(Valor);

            for (int i = 0; i < Hijos.Count(); i++)
            {
                (Hijos.ElementAt(i) as ArbolSuma).Imprimir(indent, i == Hijos.Count() - 1);
            }
        }
    }
}
