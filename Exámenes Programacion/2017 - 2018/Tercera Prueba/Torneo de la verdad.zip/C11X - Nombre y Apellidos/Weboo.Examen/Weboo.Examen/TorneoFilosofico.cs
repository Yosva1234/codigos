﻿using ConceptosSocraticos;
using System;
using System.Collections.Generic;

namespace Weboo.Examen
{
    public class TorneoFilosofico : ITorneoFilosofico
    {
        public string Compite(string escuela1, string escuela2)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<string> DameEscuelas()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Filosofo> FilosofosMasDestacados()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Filosofo> Miembros(string escuela)
        {
            throw new NotImplementedException();
        }

        public string PerteneceAEscuela(Filosofo filosofo)
        {
            throw new NotImplementedException();
        }

        public void RegistraEscuela(string escuela, IEnumerable<Filosofo> filosofos)
        {
            throw new NotImplementedException();
        }
    }
}
