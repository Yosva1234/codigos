﻿using System.Collections.Generic;
using Weboo.Examen.ColaAmigable.Interfaces;
using System;

namespace Weboo.Examen.ColaAmigable.Tester
{
    class Program
    {
        static void Main(string[] args)
        {
            ColaAmigable<Estudiante> colaAmigable = new ColaAmigable<Estudiante>();

            colaAmigable.Enqueue(new Estudiante("Jose", "C312"));    // Jose
            colaAmigable.Enqueue(new Estudiante("Maria", "C312"));   // Maria-Jose

            Estudiante e1 = colaAmigable.Peek(); // Maria
            Console.WriteLine(e1.Nombre);

            colaAmigable.Enqueue(new Estudiante("Juan", "C513"));    // Maria-Jose-Juan
            colaAmigable.Enqueue(new Estudiante("Amanda", "C312"));  // Maria-Amanda-Jose-Juan

            int count1 = colaAmigable.Count; // 4
            Console.WriteLine(count1);

            Print(colaAmigable.ColadosPor(new Estudiante("Jose", "C312"))); // Maria-Amanda
            Print(colaAmigable.ColadosPor(new Estudiante("Amanda", "C312"))); // ningún elemento
            Print(colaAmigable.ColadosPor(new Estudiante("Juan", "C513"))); // ningún elemento
            
            Estudiante e2 = colaAmigable.Dequeue();  // Amanda-Jose-Juan
            Console.WriteLine(e2.Nombre); // María

            int count2 = colaAmigable.Count; // 3
            Console.WriteLine(count2);

            Print(colaAmigable.ColadosPor(new Estudiante("Jose", "C312"))); // Amanda
        }

        static void Print<T>(IEnumerable<T> items)
        {
            foreach (var item in items)
                Console.Write("{0}, ", item);

            Console.WriteLine();
        }
    }

    public class Estudiante : IConocido<Estudiante>
    {
        public string Nombre { get; set; }

        public string Grupo { get; set; }

        public Estudiante(string nombre, string grupo)
        {
            Nombre = nombre;
            Grupo = grupo;
        }

        public bool Conoce(Estudiante aquien)
        {
            return Grupo == aquien.Grupo;
        }

        public override bool Equals(object obj)
        {
            if (obj is Estudiante)
            {
                var estudiante = obj as Estudiante;
                return Grupo == estudiante.Grupo && Nombre == estudiante.Nombre;
            }
            return false;
        }
    }

}
