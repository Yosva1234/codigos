﻿using System;
using System.Collections.Generic;
using Weboo.Examen.ColaAmigable.Interfaces;

namespace Weboo.Examen.ColaAmigable
{
    public class ColaAmigable<T> : IColaAmigable<T> where T : IConocido<T>
    {
        public ColaAmigable()
        {
            
        }

        public void Enqueue(T elemento)
        {
            throw new NotImplementedException();
        }

        public T Dequeue()
        {
            throw new NotImplementedException();
        }

        public T Peek()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<T> ColadosPor(T quien)
        {
            throw new NotImplementedException();
        }

        public int Count { get; private set; }
    }
}
