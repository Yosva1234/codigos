﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolucionCaminosEnergia
{
    public class Examen
    {
        public static bool HayCamino(int[,] matriz, int f1, int c1, int f2, int c2, int consumoMaximo)
        {
            // SUSTITUYA LA SIGUIENTE LINEA POR SU IMPLEMENTACION
            return false;
        }
    }
}
