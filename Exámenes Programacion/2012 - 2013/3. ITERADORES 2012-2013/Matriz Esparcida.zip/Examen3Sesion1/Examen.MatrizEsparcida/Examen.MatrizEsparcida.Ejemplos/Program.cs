﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Weboo.ExamenI;

namespace Examen.MatrizEsparcida.Ejemplos
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Ejemplos Matriz

            Console.WriteLine("Si no has descomentado el ejemplo correspondiente no pasara nada :)");

            #region Ejemplo 1

            //int cienMillones = 100000000;

            ////crea una matriz de tamaño 10^8 x 10^8
            //IMatriz matriz = new Matriz(cienMillones, cienMillones);
            //
            //            //Inserción de 3 valores aislados en la matriz
            //            matriz.Inserta(new CeldaMatriz(0, 0, 10));
            //            matriz.Inserta(new CeldaMatriz(1, 0, 20));
            //            matriz.Inserta(new CeldaMatriz(cienMillones - 1, 0, 30));
            //
            //            Console.WriteLine(matriz.ValorEn(1,0)); //imprime 20
            //            Console.WriteLine(matriz.ValorEn(cienMillones-1,0));//imprime 30
            //            Console.WriteLine(matriz.ValorEn(5,5)); //imprime 0
            //
            //            Console.WriteLine("Imprimiendo valores en la fila 0:");
            //            foreach (CeldaMatriz celda in matriz.Fila(0))
            //            {
            //                Console.WriteLine(celda);
            //            }
            //            //Note que la fila 0 solamente contiene un valor distinto de 0
            //            //por lo que se imprime:
            //            //10 en (0;0)
            //
            //            Console.WriteLine("Imprimiendo valores en la columna 0:");
            //            foreach (CeldaMatriz celda in matriz.Columna(0))
            //            {
            //                Console.WriteLine(celda);
            //            }
            //            //Se imprime:
            //            //10 en (0;0)
            //            //20 en (1;0)
            //            //30 en (99999999;0)
            //
            //            Console.WriteLine("Imprimiendo valores en la columna 5:");
            //            foreach (CeldaMatriz celda in matriz.Columna(5))
            //            {
            //                Console.WriteLine(celda);
            //            }
            //            //Note que la columna 5 no existen valores distintos de 0
            //            //por lo que no se imprime nada
            //
            //            //eliminar elemento en la posición 1;0
            //            matriz.Inserta(new CeldaMatriz(1,0,0));
            //
            //            Console.WriteLine("Imprimiendo valores en la columna 0:");
            //            foreach (CeldaMatriz celda in matriz.Columna(0))
            //            {
            //                Console.WriteLine(celda);
            //            }
            //            //Se imprime:
            //            //10 en (0;0)
            //            //30 en (99999999;0)
            //
            //            
            //            Console.WriteLine(matriz.ValorEn(cienMillones,cienMillones));
            //            //lanza excepcion del tipo IndexOutOfRangeException

            #endregion

            #region Ejemplo 2
            //int milMillones = 1000000000;

            ////crea una matriz de tamaño 10^9 x 10^9
            //IMatriz matriz = new Matriz(milMillones, milMillones);
            //matriz.Inserta(new CeldaMatriz(0, 0, 10));
            //matriz.Inserta(new CeldaMatriz(1, 0, 20));
            //matriz.Inserta(new CeldaMatriz(2, 0, -40));
            //matriz.Inserta(new CeldaMatriz(milMillones - 1, 0, 30));

            //Console.WriteLine(matriz.CantidadDeElementosNoNulos); //imprime 4

            //IMatriz matriz2 = new Matriz(milMillones, milMillones);
            //matriz2.Inserta(new CeldaMatriz(0, 0, 10));
            //matriz2.Inserta(new CeldaMatriz(0, 1, 50));
            //matriz2.Inserta(new CeldaMatriz(1, 1, 20));
            //matriz2.Inserta(new CeldaMatriz(2, 0, 40));
            //matriz2.Inserta(new CeldaMatriz(milMillones - 1, milMillones - 1, 30));
            //Console.WriteLine(matriz2.CantidadDeElementosNoNulos); //imprime 5

            //Console.WriteLine();

            //matriz.Adiciona(matriz2);

            ////iteracion sobre todos los elementos no nulos de la matriz
            //foreach (CeldaMatriz celdaMatriz in matriz)
            //{
            //    Console.WriteLine(celdaMatriz);
            //}
            ////Se imprime (el orden de los elementos no es importante):
            ////20 en (1;0)
            ////30 en (999999999;0)
            ////20 en (0;0)
            ////50 en (0;1)
            ////20 en (1;1)
            ////30 en (999999999;999999999)

            ////notese como no se imprime la celda (2;0) producto de que fue
            ////anulada como resultado de la suma.

            //Console.WriteLine();

            //Console.WriteLine(matriz.CantidadDeElementosNoNulos); //imprime 6

            #endregion

            #endregion

            Console.ReadLine();
        }
    }
}
