using System;
using System.Collections.Generic;
using System.Text;

namespace Examen.Ajedrez.Testing
{
    class Program
    {
        static void Main(string[] args)
        {
            TableroAjedrez tablero = new TableroAjedrez();

            // Ponga su codigo de prueba aqui

        }
    }
}
