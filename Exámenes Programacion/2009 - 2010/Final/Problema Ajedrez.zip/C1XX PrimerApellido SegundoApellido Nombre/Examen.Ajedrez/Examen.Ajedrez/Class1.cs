using System;
using System.Collections.Generic;
using System.Text;
using Weboo.Examen;

namespace Examen.Ajedrez
{
    public class TableroAjedrez : ITableroAjedrez
    {
        public TableroAjedrez()
        {
        }

        #region ITableroAjedrez Members

        public IEnumerable<Casilla> Amenazadas
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public int CantidadDeAmenazadas(ColorPieza color)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void ColocaPieza(Pieza pieza, Casilla casilla)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void MuevePieza(Casilla casillaOrigen, Casilla casillaDestino)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public IEnumerable<Casilla> PiezasQueMasAmenazan
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public bool PuedeMoverse(Casilla casillaOrigen, Casilla casillaDestino)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public IEnumerable<Casilla> PuedenMoverseHacia(Casilla casilla)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public Pieza this[Casilla casilla]
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        #endregion
    }
}
