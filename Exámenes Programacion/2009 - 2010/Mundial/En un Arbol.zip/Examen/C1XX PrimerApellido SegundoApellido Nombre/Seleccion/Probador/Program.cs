using System;
using System.Collections.Generic;
using System.Text;

namespace Mundial
{
    class Program
    {
        static void Main(string[] args)
        {
            //
            //C�digo para probar su soluci�n
            //
        }
    }
}
