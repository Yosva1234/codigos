using System;
using System.Collections.Generic;
using System.Text;
using Weboo.Utils;

namespace Mundial
{
    public class Seleccion
    {
        public static Arbol<T> MasDescendientes<T>(Arbol<T> arbol, int k, Filtro<T> condicion)
        {
            //
            //C�digo de su soluci�n
            //

            return null;
        }
    }
}
