using System;
using System.Collections.Generic;
using System.Text;
using LibEjercicioMitad;

namespace EjercicioMitad
{
    public class Solucion
    {
        public static Arbol<T> Mitad<T>(Arbol<T> a)
        {
            // escriba aqui su implementacion
            return null;
        }
    }
}
