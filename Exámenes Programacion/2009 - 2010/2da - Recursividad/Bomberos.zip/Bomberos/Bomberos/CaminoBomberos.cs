﻿namespace Bomberos
{
    /// <summary>
    /// Clase que debe de implementar el método UbicaEstacionesDeBomberos.
    /// </summary>
    public class CaminoBomberos
    {
        /// <summary>
        /// Método que retorna un arreglo con las posiciones de las tres estaciones de 
        /// bomberos para que la cantidad de poblaciones protegidas sea la mayor.
        /// </summary>
        /// <param name="distancias">Es una matriz de enteros donde se tienen la distancia
        /// entre todas las poblaciones. La diagonal es 0 ya que la distancia entre de una 
        /// población con ella misma es cero. Entre dos poblaciones que no tengan un camino 
        /// directo el valor que aparecerá en la tabla es -1.</param>
        /// <param name="alcanzeMaximo">Es la distancia máxima que puede alcanzar cualquiera 
        /// de las estaciones de bomberos.</param>
        /// <returns>Array de tres enteros que representan las poblaciones donde se sitúan 
        /// las estaciones </returns>
        public static int[] UbicaEstacionesDeBomberos(int[,] distancias,
                                             int alcanzeMaximo)
        {
            // Implementar ... 
        }

       
    }
}
