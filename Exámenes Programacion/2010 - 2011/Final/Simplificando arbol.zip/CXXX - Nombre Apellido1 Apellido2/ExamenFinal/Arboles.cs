using System;
using System.Collections.Generic;
using System.Text;
using Weboo.Utils;

namespace ExamenFinal
{
    public class Arboles
    {
        public static void Simplifica<T>(Arbol<T> arbol, Condicion<T> condicion)
        {
            //Agregue su implementacion aqui
        }
    }
}
