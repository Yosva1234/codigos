using System;
using System.Collections.Generic;
using System.Text;
using Weboo.Utils;
using ExamenFinal;

namespace Probador
{
    class Program
    {
        static void Main(string[] args)
        {
            //Construcci�n del �rbol utilizado en el ejemplo
            //ver Figura 1
            Arbol<int> arbol = new Arbol<int>(1,
                new Arbol<int>(20,
                    new Arbol<int>(3),
                    new Arbol<int>(17)
                ),
                new Arbol<int>(5),
                new Arbol<int>(6,
                    new Arbol<int>(7,
                        new Arbol<int>(22,
                            new Arbol<int>(21)
                        )
                    ),
                    new Arbol<int>(8),
                    new Arbol<int>(16,
                        new Arbol<int>(9),
                        new Arbol<int>(15)
                    )
                ),
                new Arbol<int>(12)
            );

            //Se invoca el m�todo Simplifica utilizando como condici�n un delegate
            //an�nimo que comprueba si el valor de la raiz es impar
            Arboles.Simplifica(arbol, delegate(int ar) { return ar % 2 == 1; });

            //Imprime en consola el �rbol simplificado
            arbol.ImprimeArbol();
        }
    }
}
