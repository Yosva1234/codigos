﻿using System;
using System.Collections.Generic;
using System.Text;
using Consultas;

namespace Probador
{
    class Program
    {

        static void Main(string[] args)
        {
            foreach (int x in new Consulta<int>(new int[] { 1, 2, 3, 4, 5 }))
                Console.WriteLine(x);
            /// Imprime los numeros del array

            Consulta<int> numeros = new Consulta<int>(new int[] { 1, 2, 3, 4, 5 });
            Consulta<int> pares = numeros.Filtra(EsPar);
            foreach (int x in pares)
                Console.WriteLine(x);

            foreach (int x in new Consulta<int>(new int[] { 1, 2, 3, 4, 5 }).Filtra(EsPar))
                Console.WriteLine(x);

            foreach (int x in new Consulta<int>(new int[] { 1, 2, 3, 4, 5 }).Filtra(delegate(int e) { return e % 2 == 0; }))
                Console.WriteLine(x);
            /// Imprime los numeros pares

            //string[] palabras = new string[] { "Hola", "Mundo", "Programacion" };
            //Consulta<int> longitudes = new Consulta<string>(palabras).Transforma<int>(p=>p.Length);
            //foreach (int lon in longitudes) 
            //    Console.WriteLine(lon);

            //string[] palabras = new string[] { "Hola", "Mundo", "Programacion" };
            //Consulta<string> longitudesPares = new Consulta<string>(palabras).Excluye(p => p.Length % 2 == 1);
            //foreach (string p in longitudesPares) 
            //    Console.WriteLine(p);

            //new Consulta<string>(new string[] { "A", "B", "C" }).Existe (x=>x.ToLower() == "c")

        }

        static bool EsPar(int e)
        {
            return e % 2 == 0;
        }
    }
}
