﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Consultas
{
    public class Consulta <T> : IEnumerable<T>
    {
        public Consulta(IEnumerable<T> e)
        {
            /// Implemente su codigo aqui
            
        }

        public IEnumerator<T> GetEnumerator()
        {
            /// Implemente su codigo aqui
             return null;
        }

        public Consulta<T> Filtra(Func<T, bool> predicado)
        {
            /// Implemente su codigo aqui
            return null;
        }

        public Consulta<R> Transforma<R>(Func<T, R> transformacion)
        {
            /// Implemente su codigo aqui
            return null;
        }

        public bool Existe(Func<T, bool> predicado)
        {
            /// Implemente su codigo aqui
            return false;
        }

        public bool ParaTodos(Func<T, bool> predicado)
        {
            /// Implemente su codigo aqui
            return false ;
        }

        public int Cantidad
        {
            get
            {
                /// Implemente su codigo aqui
                return 0;
            }
        }

        public Consulta<T> Salta(int n)
        {
            /// Implemente su codigo aqui
            return null;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
