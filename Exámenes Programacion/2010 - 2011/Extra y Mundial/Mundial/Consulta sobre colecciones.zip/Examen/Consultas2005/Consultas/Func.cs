﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Consultas
{
    public delegate R Func<T, R> (T elemento);
}
