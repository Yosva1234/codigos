﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Weboo.Examen.DerivandoPolinomios;

namespace Weboo.Examen.Tester
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] p1 = { 5, 3, 6, 2 };
            int[] r1 = Polinomios.Derivar(p1, 1);
            EscribePolinomio(r1); // 3 + 12*x^1 + 6*x^2

            int[] r2 = Polinomios.Derivar(p1, 2);
            EscribePolinomio(r2); // 12 + 12*x^1

            int[] r3 = Polinomios.Derivar(p1, 3);
            EscribePolinomio(r3); // 12

            int[] r4 = Polinomios.Derivar(p1, 4);
            EscribePolinomio(r4); // 0

            int[] r5 = Polinomios.Derivar(p1, 5);
            EscribePolinomio(r5); // 0

            int[] p6 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int[] r6 = Polinomios.Derivar(p6, 4);
            EscribePolinomio(r6); // 120 + 720*x^1 + 2520*x^2 + 6720*x^3 + 15120*x^4

            int[] p7 = { 3, 0, 6, 0, 2, 0, 7 };
            int[] r7 = Polinomios.Derivar(p7, 4);
            EscribePolinomio(r7); // 48 + 0*x^1 + 2520*x^2

            int[] p8 = { 0 };
            int[] r8 = Polinomios.Derivar(p8, 1000);
            EscribePolinomio(r8); // 0
        }

        static void EscribePolinomio(int[] polinomio)
        {
            Console.Write(polinomio[0]);

            for (int i = 1; i < polinomio.Length; i++)
            {
                Console.Write(" + {0}*x^{1}", polinomio[i], i);
            }

            Console.WriteLine();
        }
    }
}
