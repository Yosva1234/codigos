﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.Examen.DerivandoPolinomios
{
    public class Polinomios
    {
        public static int[] Derivar(int[] p, int k)
        {
            // Borre la siguiente línea y escriba su código aquí
            throw new NotImplementedException();
        }
    }
}
