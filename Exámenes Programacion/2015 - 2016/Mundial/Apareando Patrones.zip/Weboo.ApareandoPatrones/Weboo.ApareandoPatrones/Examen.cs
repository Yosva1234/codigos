﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weboo.ApareandoPatrones
{
    public static class Examen
    {
        public static int CantidadCoincidencias(string patron, string cadena)
        {
            // Borre esta línea y escriba su código aquí
            throw new NotImplementedException();
        }
    }
}
