﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Balanzas;

namespace Weboo.Examen
{
    public class ExamenMundial
    {

        public static bool Equilibrar(IBalanza balanza, int bolas, int pesoBolas)
        {
            throw new NotImplementedException();
        }
    }
}
