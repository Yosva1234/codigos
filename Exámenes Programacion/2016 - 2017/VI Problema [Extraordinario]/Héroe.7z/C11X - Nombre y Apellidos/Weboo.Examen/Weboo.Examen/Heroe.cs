﻿using System;
using System.Collections.Generic;

namespace Weboo.Examen
{
    public class Heroe
    {
        public static IEnumerable<Tuple<int, int>> Resuelve(int[,] bonificaciones)
        {
            throw new NotImplementedException();
        }
    }
}
